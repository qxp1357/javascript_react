import logo from './logo.svg';
import './App.css';
import styled from 'styled-components';
import React from 'react';

import {Route, Routes} from "react-router-dom";
import Home from './view/home';
import PostPage from './component/postPage';



function App() {

  return (
    <Routes>
      <Route path ="/" element={<Home/>}/>
      <Route path="/postPage/:currentTab/:index/:id" element={<PostPage/>}/>
       
    </Routes>
  );
}

export default App;
