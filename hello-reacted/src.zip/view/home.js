import React ,{useLayoutEffect, useState} from 'react';
import {atom, useRecoilState} from "recoil";
import axios from 'axios';
import {Link} from "react-router-dom";
import styled from 'styled-components';
import {userDataAtom, tabContainerAtom} from "../component/atoms";

const TabMenu = styled.ul`
  background-color: #dcdcdc;
  font-weight: bold;
  display: flex;
  flex-direction: row;
  justify-items: center;
  align-items: center;
  list-style: none;

  .submenu {
    width:100% auto;
    padding: 15px 10px;
    cursor: pointer;
  }
`;

//아톰 키값이 중복생성된다는 경고 문구가 출력됨//리코일 공식 이슈임


const tabNameList ={
  total:"전체", nonComplete:"작성중",complete:"완료"
};
const Home =()=>{
    const [userData, setUserData]=useRecoilState(userDataAtom);

    const [currentTab, setCurrentTab] = useState(0);

    const [tabContainer, setTabContainer] = useRecoilState(tabContainerAtom);
   
 
    const makeUserFilterList = (data)=>{

        let tempList =[]; 
            let total = [];
            let nonComplete = [];
            let complete =[];


        total = data;
        data.map((item)=>{
            if(item.completed){
                complete.push(item)
            }else{
                nonComplete.push(item)
            }
        })
        tempList = [total,nonComplete,complete]
    
        setTabContainer(tempList);
        }

        
    const  getUserData =()=>{
        return axios({
          method:"get",
          url:"https://jsonplaceholder.typicode.com/todos",
        }).then((res)=>{
          setUserData(res.data);
          makeUserFilterList(res.data);
        })
      }
    
      useLayoutEffect(()=>{
        getUserData();
      },[]);
  

    const makeCurrentListUserCount = ()=>{

        // let userCount = tabContainer[currentTab].filter(item => item.id !== "").length;
        let userCount = tabContainer[currentTab]?.filter(item => item.id !== "").length;

        return "총 작성글 수 : " +  userCount + " 개";
      }

      const onClickEvent = (e)=>{
          console.log("onClickEvent : e", e );
          console.log("onClickEvent : e.target.id", e.target.id );
          console.log("onClickEvent : euserId", e.target.userId );
          // setUserId()
    }

    const tabMenuHandler = (index)=>{

        setCurrentTab(index);
    }
    


    return <div>
        <h1>
            게시판
            </h1>
            <div>
        <h1>
        <TabMenu>
          <ul style={{listStyle:"none"}}>
            {Object.keys(tabNameList).map((item, index)=>{
              return <li style={{float:"left", marginRight:"20px"}}
              key={index}
              onClick={()=>{tabMenuHandler(index)}}
              >
                    {tabNameList[item]}
                </li>;
            })}
            </ul>
        </TabMenu>
        {makeCurrentListUserCount()}
        </h1>
      </div>
      <ul>

      {tabContainer[currentTab]?.map((item,index)=>{
          return(
          <li
           align ="start" 
            onClick={onClickEvent}
            userId ={item.userId}
            id ={item.Id}
            title={item.title}
            completed={item.completed}
          >
                <Link to={`postPage/${currentTab}/${index}/${item.id}`}> 
                  {"userId :"+item.userId +
            "title : " + item.title
        }
        </Link>
        </li>)
      })}
      </ul>
    
    </div>;
}

export default Home;