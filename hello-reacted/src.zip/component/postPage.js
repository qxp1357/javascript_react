



import React ,{useLayoutEffect, useState} from 'react';
import {useRecoilState} from "recoil";
import { useParams } from 'react-router-dom';
import { Outlet } from 'react-router-dom';
import {userDataAtom, tabContainerAtom} from "../component/atoms";

//특이사항 : 전체 데이터에 있는 id는 Number 값이고, params로 넘어오는 id는 string임 
//연산해야하므로 params를 Number로 수정해야함 


const PostPage =(param)=>{
    const params = useParams(); //id 값만 가져옴 
    const [selectedId, setSelectedId] = useState(Number(params.id)); //가져온 id 값을 state에 할당 
    const [currentTab, setCurrentTab] = useState(Number(params.currentTab)); //가져온 tab 값을 state에 할당 
    const [selectedIndex, setSelectedIndex] = useState(Number(params.index)); //가져온 index 값을 state에 할당 
    const [selectedUserId,setSelectedUserId] = useState("");
    const [userData, setUserData]=useRecoilState(userDataAtom); //전체 데이터 아톰 가져옴
    const [tabContainer, setTabContainer] = useRecoilState(tabContainerAtom);
    const [filteredUserPostList, setFilteredUserPostList ] = useState([]);
    const [currentUserData, setCurrentUserData] = useState([]); //현재 출력할 데이터 state 선언
    const [dataKeys, setDataKeys] = useState([]);

//현재 출력할 데이터를 전체에서 필터링해서 걸러냄
const makeUserPost = ()=>{
  let tempUser = "";
  tabContainer[currentTab].map((item)=>{
    if(item.id === selectedId){
      setCurrentUserData(item);
      setDataKeys(Object.keys(item))
      setSelectedUserId(item.userId);
      tempUser = item;
    }
  })
  let tempContainer = tabContainer[currentTab].filter(item=> item.userId === tempUser.userId);
  setFilteredUserPostList(tempContainer);
  setSelectedIndex(tempContainer.findIndex(item => item.id === tempUser.id));
}

const makeGoPrevPostButton = ()=>{
  if(selectedIndex > 0 ){
    setCurrentUserData(filteredUserPostList[selectedIndex-1]);
    setSelectedIndex(selectedIndex-1);
  }
};

const makeGoNextPostButton = ()=>{
  if(selectedIndex < filteredUserPostList.length-1){
    setCurrentUserData(filteredUserPostList[selectedIndex+1]);
    setSelectedIndex(selectedIndex+1);
  }
};

useLayoutEffect(()=>{
  setSelectedId(Number(params.id));
  makeUserPost();
},[]);


console.log("userData : ", userData);
console.log("tabContainer : ", tabContainer);
console.log("params : ", params); // params.id = 1 <=유저 아이디가  넘어옴
console.log("selectedId : ", selectedId); // params.id = 1 <=유저 아이디가  넘어옴
console.log("dataKeys : ", dataKeys);
console.log("selectedUserId : ", selectedUserId);
console.log("selectedIndex : ", selectedIndex);
    return (<div>
 <ul>
      {dataKeys.map((item,index)=>{
        return(  <li>
            {item + " : " + currentUserData[item]}
          </li>);
      })}
    </ul>
{/* {userData[`${params.id}`].id} */}
<button onClick={makeGoPrevPostButton}>
  이전글
</button>
<button onClick={makeGoNextPostButton}>
  다음글
</button>
<Outlet/>
</div>
);
}

export default PostPage;